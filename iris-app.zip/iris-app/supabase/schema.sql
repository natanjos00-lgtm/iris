-- Esquema da ÍRIS (já aplicado no projeto "iris"). Rode no SQL Editor para recriar do zero.
create table public.items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  area text not null default 'pessoal' check (area in ('pessoal','trabalho','faculdade')),
  kind text not null default 'tarefa', title text not null default '', date date,
  focus boolean not null default false, done boolean not null default false, done_at timestamptz,
  steps jsonb not null default '[]'::jsonb, done_dates jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(), extra jsonb not null default '{}'::jsonb);
create table public.fintx (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  type text not null check (type in ('entrada','saida')), amount numeric(12,2) not null,
  descr text not null default '', cat text, method text, card text,
  date date not null default current_date, month text not null check (month ~ '^\d{4}-\d{2}$'),
  fixed_id text, inst jsonb, created_at timestamptz not null default now(), extra jsonb not null default '{}'::jsonb);
create table public.fin (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  key text not null, data jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now(),
  primary key (user_id, key));
create index items_user_idx on public.items (user_id, area);
create index fintx_user_month_idx on public.fintx (user_id, month);
alter table public.items enable row level security;
alter table public.fintx enable row level security;
alter table public.fin enable row level security;
create policy "items: dono" on public.items for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "fintx: dono" on public.fintx for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "fin: dono" on public.fin for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
